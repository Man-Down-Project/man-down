#include <Arduino.h>
#include <WiFiS3.h>
#include <PubSubClient.h>

#include "node.hpp"
#include "mqtt_client.hpp"
#include "config.hpp"



WiFiClient wifiClient;
PubSubClient mqttClient(wifiClient);

const char* broker = MQTT_BROKER;
const int port = 1883;

char topic[MAX_TOPIC_SIZE];

static unsigned long lastWifiAttempt = 0;
static unsigned long lastMQTTAttempt = 0;

#define WIFI_RETRY_INTERVAL 5000
#define MQTT_RETRY_INTERVAL 5000

void mqtt_init() {

    mqttClient.setServer(MQTT_BROKER, MQTT_PORT);
    snprintf(topic, sizeof(topic), "mesh/node/%d/edge", my_node.node_id);
}

void mqtt_handle_wifi() {

    if (WiFi.status() == WL_CONNECTED) 
        return;

    if (millis() - lastWifiAttempt < WIFI_RETRY_INTERVAL)
        return;
    
    lastWifiAttempt = millis();

    Serial.println("Connecting Wifi...");
    WiFi.begin(WIFI_SSID, WIFI_PASS);
    Serial.print("Wifi status: ");
    Serial.println(WiFi.status());
    
}

void mqtt_handle_connection() {

    if (WiFi.status() != WL_CONNECTED) {
        
        Serial.print("WiFi status: ");
        Serial.println(WiFi.status());
        return;
    }
    if (WiFi.localIP() == IPAddress(0,0,0,0))
        return;
    
    WiFiClient test;

    if (!test.connect(MQTT_BROKER, MQTT_PORT)) {
        Serial.println("TCP connection FAILED");
    } else {
        Serial.println("TCP connection OK");
        test.stop();
    }
    if (mqttClient.connected())
        return;
    if (wifiClient.connected())
        return;

    if (millis() - lastMQTTAttempt < MQTT_RETRY_INTERVAL)
        return;

    lastMQTTAttempt = millis();
    Serial.println("Connecting MQTT...");

    if (mqttClient.connect("node_test")) {
        Serial.println("MQTT connected");
    }else{
        Serial.print("MQTT failed: ");
        Serial.println(mqttClient.state());
    }
}

bool mqtt_publisher_edge_event(edge_event_t* pkt) {

    if (!mqttClient.connected())
        return false;

    edge_event_out msg = {
        pkt->device_id,
        pkt->event_type,
        pkt->location,
        pkt->battery,
        pkt->seq
    };
    return mqttClient.publish(
        topic,
        (uint8_t*)&msg,
        sizeof(msg)
    );
}

void mqtt_loop(){

    mqtt_handle_wifi();
    mqtt_handle_connection();

    if (mqttClient.connected())
        mqttClient.loop();
}